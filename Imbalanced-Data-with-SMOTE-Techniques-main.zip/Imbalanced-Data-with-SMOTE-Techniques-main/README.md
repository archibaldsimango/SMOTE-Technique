The article has been published in Analytics Vidhya. Do give it a read.
https://www.analyticsvidhya.com/blog/2020/10/overcoming-class-imbalance-using-smote-techniques/
